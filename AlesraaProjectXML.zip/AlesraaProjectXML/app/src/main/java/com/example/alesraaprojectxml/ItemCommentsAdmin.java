package com.example.alesraaprojectxml;

public class ItemCommentsAdmin {
    String name;
    String comments;

    public ItemCommentsAdmin(String name, String comments) {
        this.name = name;
        this.comments = comments;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }
}
