package com.example.alesraaprojectxml;

public class ItemRvHomeWork {
    private String nameHomWork;
    private String mark;

    public ItemRvHomeWork(String nameHomWork, String mark) {
        this.nameHomWork = nameHomWork;
        this.mark = mark;
    }

    public String getNameHomWork() {
        return nameHomWork;
    }

    public void setNameHomWork(String nameHomWork) {
        this.nameHomWork = nameHomWork;
    }

    public String getMark() {
        return mark;
    }

    public void setMark(String mark) {
        this.mark = mark;
    }


}
